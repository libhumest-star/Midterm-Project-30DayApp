# 30 Days of Gourmet — Design

**Date:** 2026-08-25
**Project:** Android Basics with Compose, Unit 3 final project
**Module:** `:app` (`com.example.a30dayapp`)

## Goal

A single-screen Android app that recommends 30 Bangkok restaurants, one per day of
the month. Each day is a card the reader can tap open to see a photo, a signature
dish, and why the place is worth the trip.

## Requirements

From the course project document:

| Requirement | How it is met |
|---|---|
| 30 tips, one per day | `Datasource.loadRestaurants()` returns exactly 30 `Restaurant` entries, days 1–30 |
| Each tip has text and an image | Every card carries a name, cuisine/area, signature dish, description, and a `@DrawableRes` photo |
| Displayed in a scrollable list or grid | `LazyColumn` of `Card`s |
| Material Design, distinct brand | Hand-written charcoal-and-saffron `ColorScheme` (light + dark), `dynamicColor` disabled, custom `Typography` |
| Animations (optional section 6) | `animateContentSize` on expand, plus a chevron that rotates 180° via `animateFloatAsState` |

## Decisions

| Decision | Choice | Reason |
|---|---|---|
| Architecture | Layered, no ViewModel | Uses only Unit 3 concepts; ViewModel is Unit 4 and adds nothing here |
| Card interaction | Tap to expand | Satisfies the list requirement and the optional animations section at once |
| Card fields | day, name, cuisine + neighbourhood, photo, signature dish, description | Price range and BTS/MRT station were considered and dropped as clutter |
| Palette | Charcoal and saffron | Distinct from the green sample app; makes food photos pop |
| Dark mode | Follow the device (`isSystemInDarkTheme()`) | Standard Android behaviour; both schemes are written |
| Font | Built-in families with a custom `Typography` | Downloadable Google Fonts needs a certificate resource that risks breaking the build. A `.ttf` in `res/font/` is a one-line swap later |
| Photos | Supplied by the user | The user's own imagery, as the project document encourages |
| State | `rememberSaveable` per card | Expansion survives rotation without a ViewModel |

## Structure

```
app/src/main/java/com/example/a30dayapp/
├── MainActivity.kt          entry point only — sets theme, calls GourmetApp()
├── model/Restaurant.kt      the data class
├── data/Datasource.kt       the 30 entries
└── ui/
    ├── GourmetApp.kt        Scaffold + CenterAlignedTopAppBar + LazyColumn
    ├── RestaurantCard.kt    one expandable card
    └── theme/
        ├── Color.kt         charcoal + saffron palette constants
        ├── Theme.kt         light and dark ColorSchemes, dynamicColor off
        └── Type.kt          custom Typography
```

Each file has one job. `Datasource` is the only place content lives, `RestaurantCard`
is the only place a card is drawn, and `GourmetApp` owns the screen scaffolding. A
change to the card's appearance touches exactly one file.

## Data model

```kotlin
data class Restaurant(
    val day: Int,
    @StringRes val nameResourceId: Int,
    @StringRes val cuisineAreaResourceId: Int,
    @StringRes val signatureDishResourceId: Int,
    @StringRes val descriptionResourceId: Int,
    @DrawableRes val imageResourceId: Int,
)
```

All user-facing text lives in `strings.xml` and is referenced by resource id — the
pattern taught in the Affirmations codelab. 30 entries times 4 strings = 120 string
resources, plus 5 for app chrome (`app_name`, `day_label`, `try_label`, `expand`,
`collapse`) — 125 in total.

Two encoding traps in `strings.xml` to watch for with this content: `&` must be
written as `&amp;` (day 9, `T&K Seafood`), and a leading or trailing apostrophe must
be escaped as `\'`. Both are silent build failures otherwise.

Drawable names are derived from the restaurant name, lowercased with punctuation
dropped — so day 9 is `r09_tk_seafood` and day 11 (`80/20`) is `r11_eighty_twenty`,
since an Android resource name cannot start with a digit or contain a slash.

## Card behaviour

Collapsed, a card shows: `Day N`, the restaurant name, `cuisine · neighbourhood`,
and a chevron.

Tapping anywhere on the card expands it to additionally show the photo, `Try:
<signature dish>`, and the description.

- Expansion state is per-card, held in `rememberSaveable { mutableStateOf(false) }`
- The card body uses `Modifier.animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium))`
- The chevron uses `Icons.Filled.KeyboardArrowDown` rotated by `animateFloatAsState`

`KeyboardArrowDown` is deliberate: it ships in material-icons **core**, so the app
avoids depending on the deprecated `material-icons-extended` artifact. No new Gradle
dependencies are needed for this project at all.

Accessibility: the whole card is one clickable target with a content description
that states the restaurant name and whether it is expanded. Photos take the
restaurant name as their content description.

## Theme

`dynamicColor` is disabled. On Android 12+ it would repaint the app with the user's
wallpaper colours and destroy the distinct brand the project asks for.

Dark scheme (the design's primary look):

| Role | Value |
|---|---|
| primary | `#EFA53D` saffron |
| onPrimary | `#3D2600` |
| primaryContainer | `#5C3B00` |
| onPrimaryContainer | `#FFDDA8` |
| secondary | `#E0C29A` |
| background / surface | `#171614` warm charcoal |
| onBackground / onSurface | `#E8E3DB` |
| surfaceVariant | `#2A2723` card container |
| onSurfaceVariant | `#D2C9BC` |
| outline | `#4E4A44` |

Light scheme:

| Role | Value |
|---|---|
| primary | `#8A5100` deep saffron |
| onPrimary | `#FFFFFF` |
| primaryContainer | `#FFDDA8` |
| onPrimaryContainer | `#2C1700` |
| secondary | `#6F5B3E` |
| background / surface | `#FFF8F2` warm cream |
| onBackground / onSurface | `#201B13` |
| surfaceVariant | `#F0E2D0` card container |
| onSurfaceVariant | `#4F4539` |
| outline | `#817567` |

`Typography` overrides `displayLarge` (app title), `titleLarge` (restaurant name),
`labelSmall` (day number and signature dish label) and `bodyMedium` (description)
with deliberate weights and letter-spacing. Each override names its `FontFamily`
explicitly so that swapping in a bundled `.ttf` is a single-line change.

## Photos

30 placeholder vector drawables ship with the app so it builds and runs before any
photo exists. Each is a warm-toned tile with a different tint, named after its
restaurant so the mapping is never ambiguous:

```
r01_jay_fai.xml   r02_thipsamai.xml   …   r30_baan_tepa.xml
```

Replacing one: delete `r01_jay_fai.xml`, add `r01_jay_fai.jpg`. Same resource name,
no code change. Keeping both files at once is a duplicate-resource build error, so
the placeholder must be deleted, not merely shadowed. A command to clear all 30 at
once is provided in the README.

## Content

30 restaurants, grouped by area so a day-by-day reader travels the city rather than
criss-crossing it. Street food, noodle shops and fine dining are interleaved
throughout rather than sorted by price.

| Day | Restaurant | Cuisine · Area | Signature dish |
|---|---|---|---|
| 1 | Jay Fai | Thai street food · Phra Nakhon | Crab omelette |
| 2 | Thipsamai | Pad thai · Phra Nakhon | Pad thai wrapped in egg |
| 3 | Krua Apsorn | Thai home cooking · Phra Nakhon | Crab with yellow chilli |
| 4 | Err Urban Rustic Thai | Thai drinking food · Phra Nakhon | Grilled pork jowl |
| 5 | Nusara | Modern Thai · Phra Nakhon | Tasting menu |
| 6 | Rongros | Riverside Thai · Phra Nakhon | Crab curry |
| 7 | Nai Ek Roll Noodles | Teochew noodles · Yaowarat | Kuay jab nam sai |
| 8 | Hua Seng Hong | Thai-Chinese · Yaowarat | Braised goose |
| 9 | T&K Seafood | Street seafood · Yaowarat | Charcoal-grilled prawns |
| 10 | Potong | Thai-Chinese fine dining · Yaowarat | Five-element tasting menu |
| 11 | 80/20 | Modern Thai · Charoen Krung | Local-ingredient tasting menu |
| 12 | Charmgang | Thai curry bar · Charoen Krung | Southern curries |
| 13 | Prachak Pet Yang | Roast duck · Bang Rak | Roast duck over rice |
| 14 | Le Du | Modern Thai · Silom | River prawn |
| 15 | Sorn | Southern Thai fine dining · Sathorn | Southern crab tasting menu |
| 16 | Sühring | Modern German · Sathorn | Tasting menu |
| 17 | Somtum Der | Isaan · Silom | Som tum pu pla ra |
| 18 | Blue by Alain Ducasse | French · Khlong San | River-view tasting menu |
| 19 | Go-Ang Pratunam Chicken Rice | Khao man gai · Pratunam | Poached chicken rice |
| 20 | Jeh O Chula | Thai noodles · Pathum Wan | Mama tom yum |
| 21 | Polo Fried Chicken | Thai fried chicken · Lumphini | Gai tod with fried garlic |
| 22 | Gaggan Anand | Progressive Indian · Lumphini | Emoji tasting menu |
| 23 | Paste Bangkok | Heritage Thai · Ratchaprasong | Historic recipe tasting menu |
| 24 | Rung Rueang Pork Noodle | Noodles · Phrom Phong | Dry pork noodles |
| 25 | Wattana Panich | Beef noodles · Ekkamai | Perpetual beef broth |
| 26 | Supanniga Eating Room | Trat and Isaan Thai · Thong Lo | Moo chamuang |
| 27 | Appia | Roman Italian · Phrom Phong | Porchetta |
| 28 | Peppina | Neapolitan pizza · Thong Lo | Margherita D.O.P. |
| 29 | Sushi Masato | Edomae sushi · Ekkamai | Omakase |
| 30 | Baan Tepa | Sustainable Thai · Suan Luang | Zero-waste tasting menu |

Descriptions are one to two sentences each, written during implementation.

**Accuracy caveat.** This list comes from training data, not a live source. Bangkok
restaurants close, relocate, and gain or lose Michelin stars. The list must be
sanity-checked before submission and any changed entry swapped out.

## Testing

**Unit test — `DatasourceTest`** (JVM, fast). This is the test that earns its keep:
30 near-identical entries make copy-paste slips close to inevitable.

- exactly 30 restaurants are returned
- days are 1 to 30, with no gaps and no repeats
- no drawable resource id is used twice
- no string resource id is used twice, checked across all four string fields
  pooled together, not per field

**UI test — `GourmetAppTest`** (instrumented, `createComposeRule`).

- the top bar title is displayed
- day 1's restaurant name is displayed
- day 1's description is absent before tapping, and present after tapping its card

## Verification

Before the work is called complete:

- `./gradlew.bat :app:assembleDebug` succeeds
- `./gradlew.bat :app:testDebugUnitTest` passes
- actual command output is shown, not summarised

Instrumented tests need a running emulator or device, so they will be written and
offered but only claimed to pass if they are actually run.

## Out of scope

Deliberately excluded to keep the project matched to Unit 3:

- ViewModel, StateFlow, or any state-holder class
- Navigation or a detail screen
- Network calls, Room, or any persistence
- Maps, search, filtering, sorting, or favourites
- Downloadable Google Fonts
