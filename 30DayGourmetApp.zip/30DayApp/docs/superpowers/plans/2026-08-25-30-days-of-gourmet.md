# 30 Days of Gourmet Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a single-screen Android app listing 30 Bangkok restaurants, one per day of the month, as tap-to-expand cards in a scrolling list.

**Architecture:** Layered but deliberately simple — a `Restaurant` data class holding resource ids, a `Datasource` object returning the 30 entries, and three UI files (`GourmetApp`, `RestaurantCard`, `theme/`). No ViewModel: card expansion is local state held in `rememberSaveable`, which keeps the whole app inside Unit 3 concepts.

**Tech Stack:** Kotlin 2.2.10, Jetpack Compose (BOM 2026.02.01), Material 3, JUnit 4, Compose UI Test. No new Gradle dependencies are added by this plan.

**Spec:** `docs/superpowers/specs/2026-08-25-30-days-of-gourmet-design.md`

---

## File structure

| File | Responsibility |
|---|---|
| `app/src/main/java/com/example/a30dayapp/MainActivity.kt` | Entry point. Sets the theme, calls `GourmetApp()`, hosts previews. |
| `app/src/main/java/com/example/a30dayapp/model/Restaurant.kt` | The data class. No logic. |
| `app/src/main/java/com/example/a30dayapp/data/Datasource.kt` | The 30 entries. The only place content lives. |
| `app/src/main/java/com/example/a30dayapp/ui/GourmetApp.kt` | Screen scaffolding: top bar + `LazyColumn`. |
| `app/src/main/java/com/example/a30dayapp/ui/RestaurantCard.kt` | One card, including its expand state and animations. |
| `app/src/main/java/com/example/a30dayapp/ui/theme/Color.kt` | Palette constants. |
| `app/src/main/java/com/example/a30dayapp/ui/theme/Theme.kt` | Light + dark `ColorScheme`, theme composable. |
| `app/src/main/java/com/example/a30dayapp/ui/theme/Type.kt` | `Typography`. |
| `app/src/main/res/values/strings.xml` | All 125 user-facing strings. |
| `app/src/main/res/drawable/r01_*.xml … r30_*.xml` | 30 placeholder photos. |
| `app/src/test/java/com/example/a30dayapp/data/DatasourceTest.kt` | Guards the 30 entries against copy-paste slips. |
| `app/src/androidTest/java/com/example/a30dayapp/GourmetAppTest.kt` | Compose UI test. |

**Renamed:** the generated theme composable `_30DayAppTheme` becomes `GourmetTheme`. The leading underscore exists only because the generated name started with a digit; since Task 1 rewrites all three theme files anyway, the rename costs nothing and every later task reads better.

**Deleted:** `Greeting` and `GreetingPreview` in `MainActivity.kt` (Task 8), and the generated `ExampleUnitTest.kt` / `ExampleInstrumentedTest.kt` (Task 10).

---

### Task 1: Brand theme

**Files:**
- Modify: `app/src/main/java/com/example/a30dayapp/ui/theme/Color.kt` (full rewrite)
- Modify: `app/src/main/java/com/example/a30dayapp/ui/theme/Type.kt` (full rewrite)
- Modify: `app/src/main/java/com/example/a30dayapp/ui/theme/Theme.kt` (full rewrite)

No test: this task produces colour and font values, which a test can only restate. Task 9's UI test covers that the theme composes without crashing.

- [ ] **Step 1: Create the branch**

```bash
git checkout -b build-gourmet-app
```

- [ ] **Step 2: Replace `Color.kt`**

```kotlin
package com.example.a30dayapp.ui.theme

import androidx.compose.ui.graphics.Color

/* Dark scheme — the charcoal and saffron look the app is designed around. */
val DarkSaffron = Color(0xFFEFA53D)
val DarkOnSaffron = Color(0xFF3D2600)
val DarkSaffronContainer = Color(0xFF5C3B00)
val DarkOnSaffronContainer = Color(0xFFFFDDA8)
val DarkTan = Color(0xFFE0C29A)
val DarkOnTan = Color(0xFF3F2E14)
val DarkTanContainer = Color(0xFF57452A)
val DarkOnTanContainer = Color(0xFFFDDEB6)
val DarkCharcoal = Color(0xFF171614)
val DarkOnCharcoal = Color(0xFFE8E3DB)
val DarkCardSurface = Color(0xFF2A2723)
val DarkOnCardSurface = Color(0xFFD2C9BC)
val DarkOutline = Color(0xFF4E4A44)

/* Light scheme — shown when the device is in light mode. */
val LightSaffron = Color(0xFF8A5100)
val LightOnSaffron = Color(0xFFFFFFFF)
val LightSaffronContainer = Color(0xFFFFDDA8)
val LightOnSaffronContainer = Color(0xFF2C1700)
val LightTan = Color(0xFF6F5B3E)
val LightOnTan = Color(0xFFFFFFFF)
val LightTanContainer = Color(0xFFFADEB9)
val LightOnTanContainer = Color(0xFF271904)
val LightCream = Color(0xFFFFF8F2)
val LightOnCream = Color(0xFF201B13)
val LightCardSurface = Color(0xFFF0E2D0)
val LightOnCardSurface = Color(0xFF4F4539)
val LightOutline = Color(0xFF817567)
```

- [ ] **Step 3: Replace `Type.kt`**

```kotlin
package com.example.a30dayapp.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/*
 * To use a real font instead: drop a .ttf into app/src/main/res/font/ and change
 * these two lines to FontFamily(Font(R.font.your_font_name)).
 */
private val DisplayFamily = FontFamily.Serif
private val BodyFamily = FontFamily.SansSerif

val Typography = Typography(
    displayLarge = TextStyle(
        fontFamily = DisplayFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = DisplayFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        letterSpacing = 0.15.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = BodyFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 1.2.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = BodyFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.25.sp,
    ),
    bodySmall = TextStyle(
        fontFamily = BodyFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.4.sp,
    ),
)
```

- [ ] **Step 4: Replace `Theme.kt`**

The `dynamicColor` parameter is removed entirely rather than defaulted to `false`. On Android 12+ it would repaint the app with the user's wallpaper colours, and a parameter that must never be `true` is better deleted than defaulted.

```kotlin
package com.example.a30dayapp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = DarkSaffron,
    onPrimary = DarkOnSaffron,
    primaryContainer = DarkSaffronContainer,
    onPrimaryContainer = DarkOnSaffronContainer,
    secondary = DarkTan,
    onSecondary = DarkOnTan,
    secondaryContainer = DarkTanContainer,
    onSecondaryContainer = DarkOnTanContainer,
    background = DarkCharcoal,
    onBackground = DarkOnCharcoal,
    surface = DarkCharcoal,
    onSurface = DarkOnCharcoal,
    surfaceVariant = DarkCardSurface,
    onSurfaceVariant = DarkOnCardSurface,
    outline = DarkOutline,
)

private val LightColorScheme = lightColorScheme(
    primary = LightSaffron,
    onPrimary = LightOnSaffron,
    primaryContainer = LightSaffronContainer,
    onPrimaryContainer = LightOnSaffronContainer,
    secondary = LightTan,
    onSecondary = LightOnTan,
    secondaryContainer = LightTanContainer,
    onSecondaryContainer = LightOnTanContainer,
    background = LightCream,
    onBackground = LightOnCream,
    surface = LightCream,
    onSurface = LightOnCream,
    surfaceVariant = LightCardSurface,
    onSurfaceVariant = LightOnCardSurface,
    outline = LightOutline,
)

@Composable
fun GourmetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = Typography,
        content = content,
    )
}
```

- [ ] **Step 5: Point `MainActivity` at the renamed theme so the project still compiles**

In `app/src/main/java/com/example/a30dayapp/MainActivity.kt`, change the import and both usages. `MainActivity` is rewritten properly in Task 8; this is the minimum to keep the build green now.

- Import: `import com.example.a30dayapp.ui.theme._30DayAppTheme` becomes `import com.example.a30dayapp.ui.theme.GourmetTheme`
- In `onCreate`: `_30DayAppTheme {` becomes `GourmetTheme {`
- In `GreetingPreview`: `_30DayAppTheme {` becomes `GourmetTheme {`

- [ ] **Step 6: Verify it compiles**

Run: `./gradlew.bat :app:compileDebugKotlin`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 7: Commit**

```bash
git add app/src/main/java/com/example/a30dayapp/ui/theme app/src/main/java/com/example/a30dayapp/MainActivity.kt
git commit -m "Add charcoal and saffron brand theme"
```

---

### Task 2: Restaurant model

**Files:**
- Create: `app/src/main/java/com/example/a30dayapp/model/Restaurant.kt`

No test: a data class with no logic has no behaviour to assert. Task 5's test exercises it through `Datasource`.

- [ ] **Step 1: Create the data class**

```kotlin
package com.example.a30dayapp.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * One day's restaurant recommendation. Text and images are held as resource ids
 * rather than literal strings so everything stays translatable.
 */
data class Restaurant(
    val day: Int,
    @StringRes val nameResourceId: Int,
    @StringRes val cuisineAreaResourceId: Int,
    @StringRes val signatureDishResourceId: Int,
    @StringRes val descriptionResourceId: Int,
    @DrawableRes val imageResourceId: Int,
)
```

- [ ] **Step 2: Verify it compiles**

Run: `./gradlew.bat :app:compileDebugKotlin`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 3: Commit**

```bash
git add app/src/main/java/com/example/a30dayapp/model/Restaurant.kt
git commit -m "Add Restaurant model"
```

---

### Task 3: Placeholder photos

**Files:**
- Create: `app/src/main/res/drawable/r01_jay_fai.xml` through `r30_baan_tepa.xml` (30 files)

Each placeholder is a plate-and-cutlery glyph on a per-restaurant tint, so the list looks alive before any real photo exists and each card is visually distinguishable while scrolling.

- [ ] **Step 1: Write the generator script**

Create `scripts/make_placeholders.sh`. Writing 30 near-identical XML files by hand invites exactly the copy-paste errors Task 5 tests for; generating them removes the risk. Resource names come from Appendix A.

```bash
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out=app/src/main/res/drawable

entries=(
  "r01_jay_fai:#4A2C1B"        "r02_thipsamai:#53301C"
  "r03_krua_apsorn:#5A3520"    "r04_err:#4E3524"
  "r05_nusara:#3F2E22"         "r06_rongros:#453026"
  "r07_nai_ek:#5B3A22"         "r08_hua_seng_hong:#63401F"
  "r09_tk_seafood:#6A4522"     "r10_potong:#4C3323"
  "r11_eighty_twenty:#3E2E24"  "r12_charmgang:#5E3524"
  "r13_prachak:#6B3F23"        "r14_le_du:#44301F"
  "r15_sorn:#5A3A28"           "r16_suhring:#3C2E26"
  "r17_somtum_der:#66451F"     "r18_blue_by_ducasse:#33302E"
  "r19_go_ang:#6E4A25"         "r20_jeh_o_chula:#5C3320"
  "r21_polo_fried_chicken:#6A4A20" "r22_gaggan_anand:#4A2E26"
  "r23_paste:#553824"          "r24_rung_rueang:#5F3D25"
  "r25_wattana_panich:#4B3524" "r26_supanniga:#59402A"
  "r27_appia:#5D3524"          "r28_peppina:#663D25"
  "r29_sushi_masato:#3A302B"   "r30_baan_tepa:#47382A"
)

for entry in "${entries[@]}"; do
  name="${entry%%:*}"
  tint="${entry##*:}"
  cat > "$out/$name.xml" <<XML
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="360dp"
    android:height="200dp"
    android:viewportWidth="360"
    android:viewportHeight="200">
    <path
        android:fillColor="$tint"
        android:pathData="M0,0h360v200h-360z" />
    <path
        android:fillColor="#EFA53D"
        android:pathData="M180,100m-44,0a44,44 0 1,0 88,0a44,44 0 1,0 -88,0" />
    <path
        android:fillColor="$tint"
        android:pathData="M180,100m-32,0a32,32 0 1,0 64,0a32,32 0 1,0 -64,0" />
    <path
        android:fillColor="#EFA53D"
        android:pathData="M118,68h7v64h-7z" />
    <path
        android:fillColor="#EFA53D"
        android:pathData="M235,68h7v64h-7z" />
</vector>
XML
done

echo "wrote ${#entries[@]} placeholder drawables to $out"
```

- [ ] **Step 2: Run it**

Run: `bash scripts/make_placeholders.sh`
Expected: `wrote 30 placeholder drawables to app/src/main/res/drawable`

- [ ] **Step 3: Confirm 30 files landed**

Run: `ls app/src/main/res/drawable/r*.xml | wc -l`
Expected: `30`

- [ ] **Step 4: Verify the resources compile**

Vector path data errors are only caught by the resource compiler, not by Kotlin, so this step is not optional.

Run: `./gradlew.bat :app:processDebugResources`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 5: Commit**

```bash
git add scripts/make_placeholders.sh app/src/main/res/drawable
git commit -m "Add 30 placeholder restaurant photos"
```

---

### Task 4: Strings

**Files:**
- Modify: `app/src/main/res/values/strings.xml` (full rewrite)

125 strings: 5 for chrome (`app_name`, `day_label`, `try_label`, `expand`, `collapse`), then 4 per restaurant (`name`, `area`, `dish`, `description`) using the prefixes in Appendix A.

Two encoding traps in this content: `&` must be written `&amp;` (day 9, `T&K Seafood`), and `%` in a formatted string must be doubled. Both fail the resource compiler, which Step 3 catches.

- [ ] **Step 1: Write the chrome strings and the first two restaurants**

Full file starts:

```xml
<resources>
    <string name="app_name">30 Days of Gourmet</string>
    <string name="day_label">DAY %1$d</string>
    <string name="try_label">TRY: %1$s</string>
    <string name="expand">Show details</string>
    <string name="collapse">Hide details</string>

    <string name="r01_name">Jay Fai</string>
    <string name="r01_area">Thai street food · Phra Nakhon</string>
    <string name="r01_dish">Crab omelette</string>
    <string name="r01_description">Auntie Fai cooks over charcoal in ski goggles, and has done for decades. The queue is long and the omelette is expensive, but no other street stall in the world holds a Michelin star.</string>

    <string name="r02_name">Thipsamai</string>
    <string name="r02_area">Pad thai · Phra Nakhon</string>
    <string name="r02_dish">Pad thai wrapped in egg</string>
    <string name="r02_description">Frying pad thai over charcoal since 1966, and still drawing a queue down Maha Chai Road every night. Order it wrapped in a thin egg blanket, with orange juice on the side.</string>
```

- [ ] **Step 2: Continue for days 3 to 30, then close the file**

Use the same four-line shape for every remaining day, taking the name, area, dish and description verbatim from Appendix A, and close with `</resources>`.

- [ ] **Step 3: Verify the resources compile**

Run: `./gradlew.bat :app:processDebugResources`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 4: Confirm the count**

Run: `grep -c '<string name=' app/src/main/res/values/strings.xml`
Expected: `125` (5 chrome strings + 30 × 4)

- [ ] **Step 5: Commit**

```bash
git add app/src/main/res/values/strings.xml
git commit -m "Add strings for 30 restaurants"
```

---

### Task 5: Datasource

**Files:**
- Create: `app/src/main/java/com/example/a30dayapp/data/Datasource.kt`
- Test: `app/src/test/java/com/example/a30dayapp/data/DatasourceTest.kt`

This is the one place TDD genuinely pays here: 30 near-identical entries referencing 150 resource ids make a mistyped `r17_name` in day 18 almost inevitable, and such a bug is invisible on screen until you scroll to it.

- [ ] **Step 1: Write the failing test**

Create `app/src/test/java/com/example/a30dayapp/data/DatasourceTest.kt`:

```kotlin
package com.example.a30dayapp.data

import com.example.a30dayapp.model.Restaurant
import org.junit.Assert.assertEquals
import org.junit.Test

class DatasourceTest {

    private val restaurants: List<Restaurant> = Datasource.loadRestaurants()

    @Test
    fun loadRestaurants_returnsThirtyEntries() {
        assertEquals(30, restaurants.size)
    }

    @Test
    fun loadRestaurants_coversDaysOneToThirtyInOrder() {
        assertEquals((1..30).toList(), restaurants.map { it.day })
    }

    @Test
    fun loadRestaurants_reusesNoImage() {
        val images = restaurants.map { it.imageResourceId }
        assertEquals(
            "a drawable is used by more than one restaurant",
            images.size,
            images.distinct().size,
        )
    }

    @Test
    fun loadRestaurants_reusesNoString() {
        val strings = restaurants.flatMap {
            listOf(
                it.nameResourceId,
                it.cuisineAreaResourceId,
                it.signatureDishResourceId,
                it.descriptionResourceId,
            )
        }
        assertEquals(
            "a string resource is used by more than one restaurant",
            strings.size,
            strings.distinct().size,
        )
    }
}
```

- [ ] **Step 2: Run it and confirm it fails**

Run: `./gradlew.bat :app:testDebugUnitTest --tests "com.example.a30dayapp.data.DatasourceTest"`
Expected: FAIL — compilation error, `Unresolved reference: Datasource`

- [ ] **Step 3: Write `Datasource.kt`**

```kotlin
package com.example.a30dayapp.data

import com.example.a30dayapp.R
import com.example.a30dayapp.model.Restaurant

/** The 30 restaurants, one per day of the month. */
object Datasource {

    fun loadRestaurants(): List<Restaurant> = listOf(
        Restaurant(
            day = 1,
            nameResourceId = R.string.r01_name,
            cuisineAreaResourceId = R.string.r01_area,
            signatureDishResourceId = R.string.r01_dish,
            descriptionResourceId = R.string.r01_description,
            imageResourceId = R.drawable.r01_jay_fai,
        ),
        Restaurant(
            day = 2,
            nameResourceId = R.string.r02_name,
            cuisineAreaResourceId = R.string.r02_area,
            signatureDishResourceId = R.string.r02_dish,
            descriptionResourceId = R.string.r02_description,
            imageResourceId = R.drawable.r02_thipsamai,
        ),
        // days 3 to 30 follow the identical shape, using the prefixes and
        // drawable names in Appendix A
    )
}
```

Write out all 30 entries. The `day` value, the `rNN_` string prefix and the drawable name must agree on every entry — that agreement is exactly what Step 4 verifies.

- [ ] **Step 4: Run the test and confirm it passes**

Run: `./gradlew.bat :app:testDebugUnitTest --tests "com.example.a30dayapp.data.DatasourceTest"`
Expected: PASS, 4 tests

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/example/a30dayapp/data/Datasource.kt app/src/test/java/com/example/a30dayapp/data/DatasourceTest.kt
git commit -m "Add Datasource with the 30 restaurants"
```

---

### Task 6: Restaurant card

**Files:**
- Create: `app/src/main/java/com/example/a30dayapp/ui/RestaurantCard.kt`

Behaviour is asserted by Task 9's UI test, which needs `GourmetApp` from Task 7 to exist first.

- [ ] **Step 1: Write the card**

**Corrected during execution.** This task originally specified `Icons.Filled.KeyboardArrowDown`, on the assumption that material-icons **core** is transitive from material3. It is not, in Compose BOM 2026.02.01 — the build failed with `Unresolved reference 'icons'`. Since `material-icons-extended` is deprecated and a whole artifact for one glyph is poor value, the chevron is a vector drawable instead: `app/src/main/res/drawable/ic_chevron_down.xml`, loaded with `painterResource`. The no-new-dependencies property holds.

```kotlin
package com.example.a30dayapp.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.a30dayapp.R
import com.example.a30dayapp.model.Restaurant

@Composable
fun RestaurantCard(
    restaurant: Restaurant,
    modifier: Modifier = Modifier,
) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    val chevronRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "chevronRotation",
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Column(
            modifier = Modifier
                .clickable { expanded = !expanded }
                .animateContentSize(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessMedium,
                    ),
                )
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.day_label, restaurant.day),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = stringResource(restaurant.nameResourceId),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                    Text(
                        text = stringResource(restaurant.cuisineAreaResourceId),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Icon(
                    imageVector = Icons.Filled.KeyboardArrowDown,
                    contentDescription = stringResource(
                        if (expanded) R.string.collapse else R.string.expand,
                    ),
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.rotate(chevronRotation),
                )
            }

            if (expanded) {
                Image(
                    painter = painterResource(restaurant.imageResourceId),
                    contentDescription = stringResource(restaurant.nameResourceId),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .padding(top = 14.dp)
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(8.dp)),
                )
                Text(
                    text = stringResource(
                        R.string.try_label,
                        stringResource(restaurant.signatureDishResourceId),
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 14.dp),
                )
                Text(
                    text = stringResource(restaurant.descriptionResourceId),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}
```

- [ ] **Step 2: Verify it compiles**

Run: `./gradlew.bat :app:compileDebugKotlin`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 3: Commit**

```bash
git add app/src/main/java/com/example/a30dayapp/ui/RestaurantCard.kt
git commit -m "Add expandable restaurant card"
```

---

### Task 7: App screen

**Files:**
- Create: `app/src/main/java/com/example/a30dayapp/ui/GourmetApp.kt`

`restaurants` is a parameter with a default rather than a value read inside the body, so Task 9's test and the previews can pass a short list instead of all 30.

- [ ] **Step 1: Write the screen**

```kotlin
package com.example.a30dayapp.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.a30dayapp.R
import com.example.a30dayapp.data.Datasource
import com.example.a30dayapp.model.Restaurant

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GourmetApp(
    modifier: Modifier = Modifier,
    restaurants: List<Restaurant> = Datasource.loadRestaurants(),
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.displayLarge,
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
            )
        },
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 8.dp,
            ),
        ) {
            items(restaurants, key = { it.day }) { restaurant ->
                RestaurantCard(
                    restaurant = restaurant,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
            }
        }
    }
}
```

The `LazyColumn` takes the scaffold's insets as `contentPadding` rather than as a `Modifier.padding`. With `Modifier.padding` the list would stop scrolling above the navigation bar, leaving a dead strip; with `contentPadding` the content scrolls under it and simply starts and ends clear of it.

- [ ] **Step 2: Verify it compiles**

Run: `./gradlew.bat :app:compileDebugKotlin`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 3: Commit**

```bash
git add app/src/main/java/com/example/a30dayapp/ui/GourmetApp.kt
git commit -m "Add app screen with top bar and restaurant list"
```

---

### Task 8: Wire up MainActivity

**Files:**
- Modify: `app/src/main/java/com/example/a30dayapp/MainActivity.kt` (full rewrite)

- [ ] **Step 1: Replace the file**

This deletes `Greeting` and `GreetingPreview`, and adds one preview per colour scheme so both can be checked in Android Studio's split view without changing the emulator's setting.

```kotlin
package com.example.a30dayapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.a30dayapp.ui.GourmetApp
import com.example.a30dayapp.ui.theme.GourmetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GourmetTheme {
                GourmetApp()
            }
        }
    }
}

@Preview(name = "Dark", showBackground = true, showSystemUi = true)
@Composable
fun GourmetAppDarkPreview() {
    GourmetTheme(darkTheme = true) {
        GourmetApp()
    }
}

@Preview(name = "Light", showBackground = true, showSystemUi = true)
@Composable
fun GourmetAppLightPreview() {
    GourmetTheme(darkTheme = false) {
        GourmetApp()
    }
}
```

- [ ] **Step 2: Build the whole debug APK**

Run: `./gradlew.bat :app:assembleDebug`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 3: Commit**

```bash
git add app/src/main/java/com/example/a30dayapp/MainActivity.kt
git commit -m "Wire MainActivity to the gourmet app"
```

---

### Task 9: UI test

**Files:**
- Create: `app/src/androidTest/java/com/example/a30dayapp/GourmetAppTest.kt`

Instrumented tests need a running emulator or device. Write them regardless; run them if one is available, and report them as unrun rather than passing if not.

- [ ] **Step 1: Write the test**

```kotlin
package com.example.a30dayapp

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.a30dayapp.ui.GourmetApp
import com.example.a30dayapp.ui.theme.GourmetTheme
import org.junit.Rule
import org.junit.Test

class GourmetAppTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun launchApp() {
        composeTestRule.setContent {
            GourmetTheme {
                GourmetApp()
            }
        }
    }

    @Test
    fun topBar_showsAppName() {
        launchApp()
        composeTestRule.onNodeWithText("30 Days of Gourmet").assertIsDisplayed()
    }

    @Test
    fun firstCard_showsRestaurantName() {
        launchApp()
        composeTestRule.onNodeWithText("Jay Fai").assertIsDisplayed()
    }

    @Test
    fun tappingCard_revealsDescription() {
        launchApp()
        composeTestRule.onNodeWithText("TRY: Crab omelette").assertDoesNotExist()
        composeTestRule.onNodeWithText("Jay Fai").performClick()
        composeTestRule.onNodeWithText("TRY: Crab omelette").assertIsDisplayed()
    }
}
```

- [ ] **Step 2: Verify the test source compiles**

This works with no emulator attached, and catches typos in the test itself.

Run: `./gradlew.bat :app:compileDebugAndroidTestKotlin`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 3: Run it if a device is connected**

Run: `./gradlew.bat :app:connectedDebugAndroidTest`
Expected: PASS, 3 tests — or, with no device, `No connected devices!`, which is reported as unrun rather than treated as a pass.

- [ ] **Step 4: Commit**

```bash
git add app/src/androidTest/java/com/example/a30dayapp/GourmetAppTest.kt
git commit -m "Add UI test for the restaurant list"
```

---

### Task 10: Clean up, document, verify

**Files:**
- Delete: `app/src/test/java/com/example/a30dayapp/ExampleUnitTest.kt`
- Delete: `app/src/androidTest/java/com/example/a30dayapp/ExampleInstrumentedTest.kt`
- Create: `README.md`

- [ ] **Step 1: Delete the generated example tests**

They assert `2 + 2 == 4` and that the package name is what the manifest already says. Both are template noise.

```bash
rm app/src/test/java/com/example/a30dayapp/ExampleUnitTest.kt
rm app/src/androidTest/java/com/example/a30dayapp/ExampleInstrumentedTest.kt
```

- [ ] **Step 2: Write `README.md`**

It must cover: what the app is, how to run it, the day-to-drawable-name table from Appendix A, and this exact photo-swapping procedure:

````markdown
## Using your own photos

Each restaurant ships with a placeholder drawable. To use a real photo,
**delete the placeholder first** — keeping `r01_jay_fai.xml` and
`r01_jay_fai.jpg` at the same time is a duplicate-resource build error.

1. Delete `app/src/main/res/drawable/r01_jay_fai.xml`
2. Add your photo as `app/src/main/res/drawable/r01_jay_fai.jpg`

The resource name is unchanged, so no Kotlin needs editing.

To clear all 30 placeholders at once:

```bash
rm app/src/main/res/drawable/r[0-3][0-9]_*.xml
```

Photo filenames must be lowercase letters, digits and underscores only.
````

- [ ] **Step 3: Run the unit tests**

Run: `./gradlew.bat :app:testDebugUnitTest`
Expected: PASS, 4 tests

- [ ] **Step 4: Build the APK**

Run: `./gradlew.bat :app:assembleDebug`
Expected: `BUILD SUCCESSFUL`

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "Add README and remove template tests"
```

- [ ] **Step 6: Report actual output**

Paste the real output of Steps 3 and 4. If either failed, say so and fix it — a plan step is not complete because it was attempted.

---

## Appendix A: Content

Every restaurant's four strings and its drawable name. Tasks 3, 4 and 5 all read from this table, so it is the single source of truth for content: change it here, not in three places.

String resources are `rNN_name`, `rNN_area`, `rNN_dish`, `rNN_description`.

| Day | Drawable | Name | Area (`rNN_area`) | Dish (`rNN_dish`) |
|---|---|---|---|---|
| 1 | `r01_jay_fai` | Jay Fai | Thai street food · Phra Nakhon | Crab omelette |
| 2 | `r02_thipsamai` | Thipsamai | Pad thai · Phra Nakhon | Pad thai wrapped in egg |
| 3 | `r03_krua_apsorn` | Krua Apsorn | Thai home cooking · Phra Nakhon | Crab with yellow chilli |
| 4 | `r04_err` | Err Urban Rustic Thai | Thai drinking food · Phra Nakhon | Grilled pork jowl |
| 5 | `r05_nusara` | Nusara | Modern Thai · Phra Nakhon | Tasting menu |
| 6 | `r06_rongros` | Rongros | Riverside Thai · Phra Nakhon | Crab curry |
| 7 | `r07_nai_ek` | Nai Ek Roll Noodles | Teochew noodles · Yaowarat | Kuay jab nam sai |
| 8 | `r08_hua_seng_hong` | Hua Seng Hong | Thai-Chinese · Yaowarat | Braised goose |
| 9 | `r09_tk_seafood` | T&amp;K Seafood | Street seafood · Yaowarat | Charcoal-grilled prawns |
| 10 | `r10_potong` | Potong | Thai-Chinese fine dining · Yaowarat | Five-element tasting menu |
| 11 | `r11_eighty_twenty` | 80/20 | Modern Thai · Charoen Krung | Local-ingredient tasting menu |
| 12 | `r12_charmgang` | Charmgang | Thai curry bar · Charoen Krung | Southern curries |
| 13 | `r13_prachak` | Prachak Pet Yang | Roast duck · Bang Rak | Roast duck over rice |
| 14 | `r14_le_du` | Le Du | Modern Thai · Silom | River prawn |
| 15 | `r15_sorn` | Sorn | Southern Thai fine dining · Sathorn | Southern crab tasting menu |
| 16 | `r16_suhring` | Sühring | Modern German · Sathorn | Tasting menu |
| 17 | `r17_somtum_der` | Somtum Der | Isaan · Silom | Som tum pu pla ra |
| 18 | `r18_blue_by_ducasse` | Blue by Alain Ducasse | French · Khlong San | River-view tasting menu |
| 19 | `r19_go_ang` | Go-Ang Pratunam Chicken Rice | Khao man gai · Pratunam | Poached chicken rice |
| 20 | `r20_jeh_o_chula` | Jeh O Chula | Thai noodles · Pathum Wan | Mama tom yum |
| 21 | `r21_polo_fried_chicken` | Polo Fried Chicken | Thai fried chicken · Lumphini | Gai tod with fried garlic |
| 22 | `r22_gaggan_anand` | Gaggan Anand | Progressive Indian · Lumphini | Emoji tasting menu |
| 23 | `r23_paste` | Paste Bangkok | Heritage Thai · Ratchaprasong | Historic recipe tasting menu |
| 24 | `r24_rung_rueang` | Rung Rueang Pork Noodle | Noodles · Phrom Phong | Dry pork noodles |
| 25 | `r25_wattana_panich` | Wattana Panich | Beef noodles · Ekkamai | Perpetual beef broth |
| 26 | `r26_supanniga` | Supanniga Eating Room | Trat and Isaan Thai · Thong Lo | Moo chamuang |
| 27 | `r27_appia` | Appia | Roman Italian · Phrom Phong | Porchetta |
| 28 | `r28_peppina` | Peppina | Neapolitan pizza · Thong Lo | Margherita D.O.P. |
| 29 | `r29_sushi_masato` | Sushi Masato | Edomae sushi · Ekkamai | Omakase |
| 30 | `r30_baan_tepa` | Baan Tepa | Sustainable Thai · Suan Luang | Zero-waste tasting menu |

Day 9's name is written `T&amp;K Seafood` above because that is the literal text that must appear in `strings.xml`. It renders as `T&K Seafood`.

### Descriptions (`rNN_description`)

1. Auntie Fai cooks over charcoal in ski goggles, and has done for decades. The queue is long and the omelette is expensive, but no other street stall in the world holds a Michelin star.
2. Frying pad thai over charcoal since 1966, and still drawing a queue down Maha Chai Road every night. Order it wrapped in a thin egg blanket, with orange juice on the side.
3. A civil-servant canteen favourite that grew into a city institution. The stir-fried crab with yellow chilli is the dish people come back for.
4. Thai drinking food tucked behind Wat Pho, in a courtyard hung with old enamel signs. Everything is grilled, fermented or pickled, and built to be shared.
5. Chef Thitid Tassanakajohn cooks in memory of his grandmother, on a rooftop above the Old Town. Book weeks ahead, and take the tasting menu.
6. A restored shophouse on the river with Wat Arun lit up across the water. Come for the view, stay for the crab curry.
7. A Yaowarat fixture serving peppery kuay jab in a clear, punishing broth. The rolled rice noodles are the whole point.
8. Chinatown comfort food since 1959. Braised goose over rice, dim sum steamers, and noodles served long past midnight.
9. Green-shirted staff, plastic stools, and prawns grilling on the pavement at Soi Texas. Loud, cheap, and exactly what Yaowarat is for.
10. Chef Pam cooks Thai-Chinese memory inside her family's 120-year-old shophouse, once a Chinese pharmacy. The menu is built around five elements.
11. Named for the ratio of Thai ingredients to everything else. A small kitchen doing serious things with produce most restaurants overlook.
12. A curry bar on Charoen Krung run by three friends who met in fine-dining kitchens. Order the southern curries and expect real heat.
13. Roasting duck in the same Bang Rak shophouse since 1909. Order it over rice, with a bowl of broth on the side.
14. Modern Thai in a converted shophouse off Silom, and once ranked the best restaurant in Asia. The river prawn is the dish to order.
15. Southern Thai cooking taken as seriously as anywhere in the world, with ingredients driven up from Trang and Phuket. The hardest table in Bangkok to book.
16. Twin brothers cooking modern German food in a 1970s house with a garden. Not what you expect in Bangkok, and better for it.
17. Isaan cooking from Ubon Ratchathani, pounded to order in a mortar you can hear from the street. Start with som tum pu pla ra if you can take it.
18. French technique on the river at Icon Siam, with Wat Arun framed in the window. The most formal meal on this list, and dress accordingly.
19. The pink-shirted khao man gai stand near Pratunam market. Poached chicken, rice cooked in the fat, and a ginger-chilli sauce doing the heavy lifting.
20. Queue numbers are handed out before opening for a reason. The mama tom yum arrives as a mountain of pork, seafood and instant noodles.
21. Thai fried chicken buried under a drift of crisp fried garlic, a short walk from Lumphini Park. Order sticky rice and som tum alongside.
22. Progressive Indian food served as a wordless emoji menu, with the chef conducting the room. Theatre and cooking in equal measure.
23. Bee Satongun rebuilds recipes from old Thai cookbooks using modern technique. Precise, balanced, and unlike anything else on this list.
24. A Sukhumvit noodle stall so popular it split into two shops side by side. Order it dry, with everything in it.
25. The beef broth in the vat out front has been topped up and simmered for decades, never once emptied. Order the beef noodle soup and taste what that does.
26. Home cooking from Trat and Isaan, built on the owner's grandmother's recipes. The moo chamuang, pork stewed with sour chamuang leaves, is the one.
27. Roman cooking in a Sukhumvit side street, with a porchetta that would hold its own in Testaccio. Sunday lunch is the move.
28. Proper Neapolitan pizza from a wood-fired oven, certified by the Naples association. The margherita is the test, and it passes.
29. A tiny Ekkamai counter with a long waiting list and fish flown in from Toyosu. Omakase only, and worth planning a month around.
30. A family home turned restaurant, cooking close to zero-waste with produce from its own garden. A quiet, generous way to finish the month.

**Accuracy caveat.** This content comes from training data, not a live source. Verify each restaurant is still open and still described accurately before submitting the project.
