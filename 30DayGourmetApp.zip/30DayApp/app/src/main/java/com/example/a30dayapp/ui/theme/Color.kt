package com.example.a30dayapp.ui.theme

import androidx.compose.ui.graphics.Color

/* Dark scheme — the charcoal and saffron look the app is designed around. */
val DarkSaffron = Color(0xFFEFA53D)
val DarkOnSaffron = Color(0xFF3D2600)
val DarkSaffronContainer = Color(0xFF5C3B00)
val DarkOnSaffronContainer = Color(0xFFFFDDA8)
val DarkTan = Color(0xFFE0C29A)
val DarkOnTan = Color(0xFF3F2E14)
val DarkTanContainer = Color(0xFF57452A)
val DarkOnTanContainer = Color(0xFFFDDEB6)
val DarkCharcoal = Color(0xFF171614)
val DarkOnCharcoal = Color(0xFFE8E3DB)
val DarkCardSurface = Color(0xFF2A2723)
val DarkOnCardSurface = Color(0xFFD2C9BC)
val DarkOutline = Color(0xFF4E4A44)

/* Light scheme — shown when the device is in light mode. */
val LightSaffron = Color(0xFF8A5100)
val LightOnSaffron = Color(0xFFFFFFFF)
val LightSaffronContainer = Color(0xFFFFDDA8)
val LightOnSaffronContainer = Color(0xFF2C1700)
val LightTan = Color(0xFF6F5B3E)
val LightOnTan = Color(0xFFFFFFFF)
val LightTanContainer = Color(0xFFFADEB9)
val LightOnTanContainer = Color(0xFF271904)
val LightCream = Color(0xFFFFF8F2)
val LightOnCream = Color(0xFF201B13)
val LightCardSurface = Color(0xFFF0E2D0)
val LightOnCardSurface = Color(0xFF4F4539)
val LightOutline = Color(0xFF817567)
