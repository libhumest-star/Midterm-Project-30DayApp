package com.example.a30dayapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.a30dayapp.ui.GourmetApp
import com.example.a30dayapp.ui.theme.GourmetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GourmetTheme {
                GourmetApp()
            }
        }
    }
}

@Preview(name = "Dark", showBackground = true, showSystemUi = true)
@Composable
fun GourmetAppDarkPreview() {
    GourmetTheme(darkTheme = true) {
        GourmetApp()
    }
}

@Preview(name = "Light", showBackground = true, showSystemUi = true)
@Composable
fun GourmetAppLightPreview() {
    GourmetTheme(darkTheme = false) {
        GourmetApp()
    }
}
