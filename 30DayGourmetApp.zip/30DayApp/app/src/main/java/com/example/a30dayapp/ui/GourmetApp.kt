package com.example.a30dayapp.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.a30dayapp.R
import com.example.a30dayapp.data.Datasource
import com.example.a30dayapp.model.Restaurant

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GourmetApp(
    modifier: Modifier = Modifier,
    restaurants: List<Restaurant> = Datasource.loadRestaurants(),
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.displayLarge,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
            )
        },
    ) { innerPadding ->
        /*
         * The scaffold's insets go in as contentPadding rather than as a
         * Modifier.padding. With Modifier.padding the list would stop scrolling
         * above the navigation bar and leave a dead strip; as contentPadding the
         * content scrolls under it and simply starts and ends clear of it.
         */
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 8.dp,
            ),
        ) {
            items(restaurants, key = { it.day }) { restaurant ->
                RestaurantCard(
                    restaurant = restaurant,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
            }
        }
    }
}
