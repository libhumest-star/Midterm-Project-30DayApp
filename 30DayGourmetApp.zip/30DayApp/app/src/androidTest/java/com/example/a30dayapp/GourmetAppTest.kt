package com.example.a30dayapp

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.a30dayapp.ui.GourmetApp
import com.example.a30dayapp.ui.theme.GourmetTheme
import org.junit.Rule
import org.junit.Test

class GourmetAppTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun launchApp() {
        composeTestRule.setContent {
            GourmetTheme {
                GourmetApp()
            }
        }
    }

    @Test
    fun topBar_showsAppName() {
        launchApp()
        composeTestRule.onNodeWithText("30 Days of Gourmet").assertIsDisplayed()
    }

    @Test
    fun firstCard_showsRestaurantName() {
        launchApp()
        composeTestRule.onNodeWithText("Jay Fai").assertIsDisplayed()
    }

    @Test
    fun tappingCard_revealsDescription() {
        launchApp()
        composeTestRule.onNodeWithText("TRY: Crab omelette").assertDoesNotExist()
        composeTestRule.onNodeWithText("Jay Fai").performClick()
        composeTestRule.onNodeWithText("TRY: Crab omelette").assertIsDisplayed()
    }
}
